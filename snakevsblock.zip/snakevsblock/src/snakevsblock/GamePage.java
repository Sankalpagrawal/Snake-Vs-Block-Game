// SANKALP AGRAWAL, 2017363
// HARSHIT RAI, 2017152

package snakevsblock;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.layout.*;
import javafx.animation.*;
import javafx.util.Duration;

public class GamePage extends Application {
	
	@Override
	public void start(Stage primarystage) {
		primarystage.setTitle("Game");
		Snake snake = new Snake();
		
		Magnet magnet = new Magnet(122,130);
		Shield shield = new Shield(150,130);
		Destroy_Token dt = new Destroy_Token(180,130);
		Ball_Token bt = new Ball_Token(210,130);
		Coin coin = new Coin(240,130);

		Block block2 = new Block(200,200);

		String st[] = { "Restart Game", "Save state of Game and Exit"}; 
		ChoiceBox<String> dropdown = new ChoiceBox<>(FXCollections.observableArrayList(st));
		dropdown.setLayoutX(200);
		dropdown.setLayoutY(1);
		dropdown.setMaxWidth(100);
		
//		MenuItem m1 = new MenuItem("Restart Game");
//		MenuItem m2 = new MenuItem("Save state of Game and Exit");
//		
//		MenuButton dropdown = new MenuButton("Options",null,m1,m2);
//		dropdown.setLayoutX(230);
//		dropdown.setLayoutY(1);

		Label curr_score = new Label("Current score");
		curr_score.setFont(new Font("Cambria",20));
		curr_score.setLayoutX(1);
		curr_score.setLayoutY(1);
		Group fin = new Group(snake,magnet,dt,bt,coin,shield,dropdown,curr_score,block2);
		Scene scene = new Scene(fin,300,500);
		
		block2.burst();
		
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			
			@Override
			public void handle(KeyEvent e) {
				switch(e.getCode()) {
					case LEFT: snake.moveLeft(); break;
					case RIGHT: snake.moveRight(); break;
				}
			}
		});
		
		AnimationTimer timer = new AnimationTimer() {
			private double t=0;
			
			@Override
			public void handle(long now) {
				if(now - t>2_000_000_000) {
					generateBlocks(fin);
					generateWalls(fin);
					t=now;
				}
			}
		};
		timer.start();
				
		scene.setFill(Color.LIGHTBLUE);
		primarystage.setScene(scene);
		primarystage.show();	
	}
	
	public void generateBlocks(Group g) {
		Random r = new Random();
		int nb = r.nextInt(3)+3;
		ArrayList<Block> arra = new ArrayList<>(nb);
		int[] arr_choices = {0,60,120,180,240};
		List<Integer> integers = IntStream.range(0, 5).boxed().collect(Collectors.toList());
		Collections.shuffle(integers);

		for(int i=0;i<nb;i++) {
			arra.add(new Block(arr_choices[integers.get(i)],0));
		}
		for(int i=0;i<nb;i++) {
			TranslateTransition translateTransition1 = new TranslateTransition(); 
			translateTransition1.setDuration(Duration.millis(2000)); 
			translateTransition1.setNode(arra.get(i)); 
			translateTransition1.setToY(500); 
			translateTransition1.play(); 
		}
		g.getChildren().addAll(arra);
		
	}
	
	public void generateWalls(Group g) {
		Random r = new Random();
		int nw = r.nextInt(2)+1;
		int[] arr_choices = {0,60,120,180,240};
		ArrayList<Wall> arra = new ArrayList<>(nw);
		List<Integer> integers = IntStream.range(1, 5).boxed().collect(Collectors.toList());
		Collections.shuffle(integers);
		
		for(int i=0;i<nw;i++) {
			arra.add(new Wall(arr_choices[integers.get(i)],0));
		}
		for(int i=0;i<nw;i++) {
			TranslateTransition translateTransition1 = new TranslateTransition(); 
			translateTransition1.setDuration(Duration.millis(2000)); 
			translateTransition1.setNode(arra.get(i)); 
			translateTransition1.setToY(500); 
			translateTransition1.play(); 
		}
		g.getChildren().addAll(arra);
	}

//	public void rungame(Group g) {
//			TranslateTransition translateTransition1 = new TranslateTransition(); 
//			TranslateTransition translateTransition2 = new TranslateTransition(); 
//		      
//		    translateTransition1.setDuration(Duration.millis(2000)); 
//		    translateTransition2.setDuration(Duration.millis(2000));
//		    
//		    translateTransition1.setNode(this.blocks); 
//		    translateTransition2.setNode(this.walls); 
//		    
//		    translateTransition1.setByY(500); 
//		    translateTransition2.setByY(500); 
//		    
//		    translateTransition1.setCycleCount(100); 
//		    translateTransition2.setCycleCount(100); 
//		    
//		    translateTransition1.setAutoReverse(false); 
//		    translateTransition2.setAutoReverse(false); 
//		      
//		    translateTransition1.play(); 
//		    translateTransition2.play();
//	}
}
