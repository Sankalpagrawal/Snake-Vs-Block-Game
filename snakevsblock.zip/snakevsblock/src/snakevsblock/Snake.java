package snakevsblock;

import javafx.scene.control.Label;
import javafx.animation.TranslateTransition;
import javafx.event.EventHandler;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;

public class Snake extends Group {
	
	public class Ball extends Circle {
		private final int radius=10;
		private final Color colour=Color.GREEN;
		
		public Ball() {
			this.setRadius(radius);
			this.setFill(colour);
		}
		
		public Ball(int cx, int cy) {
			this.setCenterX(cx);
			this.setCenterY(cy);
			this.setRadius(radius);
			this.setFill(colour);
		}
	}

	private int length;
	
	public Snake() {
		this.length=5;
		Label l = new Label(String.valueOf(this.length));
		l.setFont(new Font("Cambria",15));
		l.setLayoutX(147);
		l.setLayoutY(280);
		this.getChildren().add(l);
		this.addBalls(this.length);
	}
	
	public void addBalls(int n) {
		for(int i=0;i<n;i++) {
			Ball bb = new Ball(150,310 + 20*i);
			this.getChildren().add(bb);
		}
	}
	
	public void moveLeft() {	
		int i=0;
		while (i<this.length+1) {
			if(i==0) {
				Label l = (Label) this.getChildren().get(i);
				l.setLayoutX(l.getLayoutX()-6);
			}
			else {
				Ball b = (Ball) this.getChildren().get(i);
				b.setCenterX(b.getCenterX()-6);
			}
			i++;
		}
	}
	
	public void moveRight() {	
		int i=0;
		while (i<this.length+1) {
			if(i==0) {
				Label l = (Label) this.getChildren().get(i);
				l.setLayoutX(l.getLayoutX()+6);
			}
			else {
				Ball b = (Ball) this.getChildren().get(i);
				b.setCenterX(b.getCenterX()+6);
			}
			i++;
		}
	}
	
}
